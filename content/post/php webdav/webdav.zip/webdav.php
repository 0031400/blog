<?php
use Sabre\DAV;
require 'vendor/autoload.php';

// This is where the webdav file folder is.
$rootDirectory = new DAV\FS\Directory('public');

// Set up the server
$server = new DAV\Server($rootDirectory);

// This is the url of the php file
$server->setBaseUri('/webdav.php');

// This is a lock plugin.It is optional.
// $lockBackend = new DAV\Locks\Backend\File('data/locks');
// $lockPlugin = new DAV\Locks\Plugin($lockBackend);
// $server->addPlugin($lockPlugin);

// This is a web control panel plugin.With it,we can get,send,list the files.It is optional.
// $server->addPlugin(new DAV\Browser\Plugin());

// This is for the auth.I think it is important.
use Sabre\DAV\Auth;
$authBackend = new Auth\Backend\File('htdigest');
$authBackend->setRealm('SabreDAV');
$authPlugin = new Auth\Plugin($authBackend);

// Run the server.
$server->exec();