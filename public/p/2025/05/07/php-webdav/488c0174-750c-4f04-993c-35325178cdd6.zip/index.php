<?php

use Sabre\DAV;
use Sabre\DAV\Auth;

require 'vendor/autoload.php';

// server
$rootDirectory = new DAV\FS\Directory('public');
$server = new DAV\Server($rootDirectory);
$server->setBaseUri('/index.php');


// auth plugin
$authBackend = new Auth\Backend\File('htdigest');
$authBackend->setRealm('SabreDAV');
$authPlugin = new Auth\Plugin($authBackend);
$server->addPlugin($authPlugin);

// run
$server->exec();